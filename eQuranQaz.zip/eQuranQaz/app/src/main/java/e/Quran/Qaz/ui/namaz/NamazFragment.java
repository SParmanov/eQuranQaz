package e.Quran.Qaz.ui.namaz;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;
import com.github.barteksc.pdfviewer.util.FitPolicy;

import e.Quran.Qaz.R;

import static android.content.Context.MODE_PRIVATE;

public class NamazFragment extends Fragment {
    public static SharedPreferences sharedPreferences1;

    private static final String BUNDLE_PAGE = "page";

    private PDFView pdfView;
    private int page = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_namaz, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        sharedPreferences1 = getContext().getSharedPreferences("Settings", MODE_PRIVATE);
        page = sharedPreferences1.getInt("book1", 0);

        pdfView = view.findViewById(R.id.pdfView);
        pdfView.fromAsset("namaz.pdf")
                .enableSwipe(true) // allows to block changing pages using swipe
                .swipeHorizontal(true)
                .enableDoubletap(true)

                .pageSnap(true)
                .autoSpacing(true)
                .pageFling(true)

                .defaultPage(savedInstanceState == null ? page : savedInstanceState.getInt(BUNDLE_PAGE, page))
                .enableAnnotationRendering(false) // render annotations (such as comments, colors or forms)
                .password(null)
                .scrollHandle(new DefaultScrollHandle(getContext()))
                .enableAntialiasing(true) // improve rendering a little bit on low-res screens
                // spacing between pages in dp. To define spacing color, set view background
                .spacing(0)
                .pageFitPolicy(FitPolicy.WIDTH)
                .load();
    }

    @Override
    public void onStop() {
        super.onStop();
        page = pdfView.getCurrentPage();

        sharedPreferences1 = getContext().getSharedPreferences("Settings", MODE_PRIVATE);
        SharedPreferences.Editor edit1 = sharedPreferences1.edit();
        edit1.putInt("book1", page);
        edit1.commit();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putInt(BUNDLE_PAGE, pdfView.getCurrentPage());
        super.onSaveInstanceState(outState);
    }
}
